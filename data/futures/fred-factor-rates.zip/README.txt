----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-11-06 5:11 am CST
----------------------------------------------------------------

--------  ----------------------------------------------------------------------  ------------------------
DGS10     Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,  Data Updated: 2026-11-05
          Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
DFII10    Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,  Data Updated: 2026-11-05
          Quoted on an Investment Basis, Inflation-Indexed, Percent, Daily, Not
          Seasonally Adjusted
DGS2      Market Yield on U.S. Treasury Securities at 2-Year Constant Maturity,   Data Updated: 2026-11-05
          Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
DFEDTARU  Federal Funds Target Range - Upper Limit, Percent, Daily, Not           Data Updated: 2026-11-05
          Seasonally Adjusted
DEXCHUS   Chinese Yuan Renminbi to U.S. Dollar Spot Exchange Rate, Chinese Yuan   Data Updated: 2026-11-02
          Renminbi to One U.S. Dollar, Daily, Not Seasonally Adjusted
--------  ----------------------------------------------------------------------  ------------------------

